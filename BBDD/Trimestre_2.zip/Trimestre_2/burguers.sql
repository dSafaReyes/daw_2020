-- MySQL dump 10.13  Distrib 5.5.62, for Win64 (AMD64)
--
-- Host: localhost    Database: burguersdb
-- ------------------------------------------------------
-- Server version	5.5.5-10.6.4-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hamburguesa`
--
DROP DATABASE IF EXISTS `burguers`;
CREATE DATABASE IF NOT EXISTS `burguers`;

USE `burguers`;

DROP TABLE IF EXISTS `hamburguesa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hamburguesa` (
    `id` int(10) NOT NULL AUTO_INCREMENT,
    `nombre` varchar(150) NOT NULL,
    `valor_calorico` double DEFAULT NULL,
    `id_hamburgueseria` int(10) NOT NULL,
    PRIMARY KEY (`id`),
    KEY `hamburguesa_hamburgueseria_fk` (`id_hamburgueseria`),
    CONSTRAINT `hamburguesa_hamburgueseria_fk` FOREIGN KEY (`id_hamburgueseria`) REFERENCES `hamburgueseria` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hamburguesa`
--

LOCK TABLES `hamburguesa` WRITE;
/*!40000 ALTER TABLE `hamburguesa` DISABLE KEYS */;
INSERT INTO `hamburguesa` VALUES (1,'Whopper',300,1),(2,'The King Bacon',370,1),(3,'Triple Whopper',500,1),(4,'Bic Mac',410,2),(5,'Cuarto de Libra',270,2),(6,'CBO',310,2),(7,'McExtreme Bacon',340,2),(8,'TGB Burguer',320,3),(9,'Cheese Burguer',315,3),(10,'BBQ Burguer',390,3),(11,'Pulled Pork BBQ',405,3),(12,'Kevin Bacon',430,4),(13,'Yankee',400,4),(14,'M-30',395,4),(15,'Kevin Costner',510,4);
/*!40000 ALTER TABLE `hamburguesa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hamburguesa_ingredientes`
--

DROP TABLE IF EXISTS `hamburguesa_ingredientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hamburguesa_ingredientes` (
    `id_hamburguesa` int(10) NOT NULL,
    `id_ingrediente` int(10) NOT NULL,
    KEY `hamburguesa_ingredientes_fk1` (`id_ingrediente`),
    KEY `hamburguesa_ingredientes_fk2` (`id_hamburguesa`),
    CONSTRAINT `hamburguesa_ingredientes_fk1` FOREIGN KEY (`id_ingrediente`) REFERENCES `ingrediente` (`id`),
    CONSTRAINT `hamburguesa_ingredientes_fk2` FOREIGN KEY (`id_hamburguesa`) REFERENCES `hamburguesa` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hamburguesa_ingredientes`
--

LOCK TABLES `hamburguesa_ingredientes` WRITE;
/*!40000 ALTER TABLE `hamburguesa_ingredientes` DISABLE KEYS */;
INSERT INTO `hamburguesa_ingredientes` VALUES (1,1),(1,2),(1,3),(1,3),(1,7),(1,8),(1,9),(1,13),(2,1),(2,2),(2,3),(2,3),(2,10),(2,6),(2,13),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(3,1),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),(9,2),(11,2),(13,2),(15,2),(3,3),(4,3),(5,4),(6,4),(7,5),(8,5),(9,5),(10,3),(11,4),(12,4),(13,5),(14,5),(15,5),(4,6),(5,8),(6,7),(7,6),(8,8),(9,8),(10,8),(11,7),(12,10),(13,10),(14,11),(15,9),(3,13);
/*!40000 ALTER TABLE `hamburguesa_ingredientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hamburgueseria`
--

DROP TABLE IF EXISTS `hamburgueseria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hamburgueseria` (
    `id` int(10) NOT NULL AUTO_INCREMENT,
    `nombre` varchar(150) NOT NULL,
    `pais_origen` varchar(100) DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hamburgueseria`
--

LOCK TABLES `hamburgueseria` WRITE;
/*!40000 ALTER TABLE `hamburgueseria` DISABLE KEYS */;
INSERT INTO `hamburgueseria` VALUES (1,'Burguer King','EEUU'),(2,'McDonald\'s','EEUU`),(3,'TGB','España'),(4,'Goiko Grill','España');
/*!40000 ALTER TABLE `hamburgueseria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrediente`
--

DROP TABLE IF EXISTS `ingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingrediente` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `valor_calorico` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrediente`
--

LOCK TABLES `ingrediente` WRITE;
/*!40000 ALTER TABLE `ingrediente` DISABLE KEYS */;
INSERT INTO `ingrediente` VALUES (1,'Pan de Hamburguesa',40),(2,'Bacon',60),(3,'Ternera 100gr ',100),(4,'Ternera 200gr ',200),(5,'Ternera 300gr ',300),(6,'Lámina de queso',30),(7,'Cebolla',15),(8,'Lechuga',5),(9,'Tomate',10),(10,'Rulo de queso de cabra',50),(11,'Pepinillos',35),(12,'Cebolla caramelizada',50),(13,'Salsa especial',30);
/*!40000 ALTER TABLE `ingrediente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ranking_hamburgueseria`
--

DROP TABLE IF EXISTS `ranking_hamburgueseria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ranking_hamburgueseria` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_hamburgueseria` int(10) NOT NULL,
  `valoracion_total` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ranking_hamburgueseria_fk` (`id_hamburgueseria`),
  CONSTRAINT `ranking_hamburgueseria_fk` FOREIGN KEY (`id_hamburgueseria`) REFERENCES `hamburgueseria` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ranking_hamburgueseria`
--

LOCK TABLES `ranking_hamburgueseria` WRITE;
/*!40000 ALTER TABLE `ranking_hamburgueseria` DISABLE KEYS */;
INSERT INTO `ranking_hamburgueseria` VALUES (1,1,200),(2,2,150),(3,3,300),(4,4,60);
/*!40000 ALTER TABLE `ranking_hamburgueseria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `valoracion_hamburguesa`
--

DROP TABLE IF EXISTS `valoracion_hamburguesa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `valoracion_hamburguesa` (
    `id` int(10) NOT NULL AUTO_INCREMENT,
    `id_hamburguesa` int(10) NOT NULL,
    `nombre_cliente` varchar(150) NOT NULL,
    `opinion` varchar(100) DEFAULT NULL,
    `valoracion` int(2) DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `valoracion_hamburguesa_fk` (`id_hamburguesa`),
    CONSTRAINT `valoracion_hamburguesa_fk` FOREIGN KEY (`id_hamburguesa`) REFERENCES `hamburguesa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `valoracion_hamburguesa`
--

LOCK TABLES `valoracion_hamburguesa` WRITE;
/*!40000 ALTER TABLE `valoracion_hamburguesa` DISABLE KEYS */;
INSERT INTO `valoracion_hamburguesa` VALUES (1,1,'Juan Gutierrez','Muy rica',9),(2,1,'Ana López','Impresionante',10),(3,1,'Joel Ramos','Espectacular',9),(4,2,'Alex Moreno ','Está Bien',6),(5,2,'Edgar ','No está mal',7),(6,2,'Germán Pezella','Rica',8),(7,3,'Héctor Bellerín','Me encanta',10),(8,4,'Willian Carvalho','Umm deliciosa',10),(9,4,'Guido Rodríguez','Un poco seca',5),(10,5,'Aitor Ruibal','De lujo',10),(11,5,'Diego Lainez','No está mal',7),(12,6,'Joaquín Sánchez','Increible hulio',10),(13,7,'Sergio Canales','Espectacular',9),(14,8,'Nabil Fekir','Si, buena',6),(15,9,'Rodri','Muy rica',9),(16,10,'Juanmi','Que buena!',10),(17,11,'Borja Iglesias','De lujo',9),(18,12,'Willian José','Rica',8),(19,13,'Marc Bartra','Increible',10),(20,14,'Victor Ruíz','Buenooo',7),(21,15,'Claudio Bravo','Me gusta ',6);
/*!40000 ALTER TABLE `valoracion_hamburguesa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'burguersdb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-04 13:11:45