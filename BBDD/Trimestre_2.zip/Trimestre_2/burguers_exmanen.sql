use burguerdb;

-- EJERCICIO 1
-- 1.-
select * from hamburguesa h where valor_calorico between 350 and 500 order by valor_calorico desc limit 5;

-- 2.- 
select h.nombre, h2.* from hamburguesa h join hamburgueseria h2 on h.id_hamburgueseria = h2.id ;

-- 3.-
select sum(h.valor_calorico), count(h2.id), h2.nombre from hamburguesa h join hamburgueseria h2 on h.id_hamburgueseria = h2.id group by h2.id ;

-- 4.-
select h.nombre, i.nombre from hamburguesa h join hamburguesa_ingredientes hi on h.id = hi.id_hamburguesa 
							join ingrediente i on hi.id_ingrediente = i.id 
order by h.nombre;

-- 5.-
select h.nombre, avg(vh.valoracion) from hamburguesa h join valoracion_hamburguesa vh on h.id = vh.id_hamburguesa group by h.id;

-- 6.- 
select h2.nombre, sum(vh.valoracion) from hamburgueseria h2 join hamburguesa h on h2.id = h.id_hamburgueseria 
								join valoracion_hamburguesa vh on h.id = vh.id_hamburguesa 
group by h2.id;

-- EJERCICIO 2
CREATE VIEW 
vista_calorias_hamburguesa AS 
select h.nombre, sum(i.valor_calorico), h2.nombre from hamburguesa h join hamburguesa_ingredientes hi on h.id = hi.id_hamburguesa 
	                                            			join ingrediente i on hi.id_ingrediente = i.id 
	                                            			join hamburgueseria h2 on h.id_hamburgueseria =h2.id 
group by h.id;

-- EJERCICIO 3
-- 1.-
DELIMITER $$
CREATE OR REPLACE FUNCTION crear_valoracion_hamburguesa(
    id_hamburguesa INT(10), cliente VARCHAR(150), comentario VARCHAR(100), valoracion INT(2)
)
RETURNS INT(10)
BEGIN
    
    DECLARE id_hamburguesa_comprobacion INT(10) default 0;
    DECLARE id_valoracion_comprobacion INT(10) default 0;
    DECLARE id_nuevo INT(10) default 0;

    SELECT id INTO id_hamburguesa_comprobacion FROM hamburguesa WHERE id=id_hamburguesa;
    SELECT id INTO id_valoracion_comprobacion FROM valoracion_hamburguesa WHERE nombre_cliente=cliente AND id_hamburguesa=id_hamburguesa;
    
    IF id_hamburguesa_comprobacion=id_hamburguesa AND id_valoracion_comprobacion=0 THEN 
        INSERT INTO valoracion_hamburguesa (id_hamburguesa, nombre_cliente, opinion, valoracion) 
        VALUES (id_hamburguesa, cliente, comentario, valoracion);
        SELECT id INTO id_nuevo FROM valoracion_hamburguesa ORDER BY id DESC LIMIT 1;
        RETURN id_nuevo;
    END IF;

    RETURN 0;

END; 
$$ 
DELIMITER
-- En este caso devolvería 0
select crear_valoracion_hamburguesa (1, 'Juan Gutierrez', 'Muy rica', 3);
-- En este caso devolvería el siguiente id
select crear_valoracion_hamburguesa (2, 'Gon', 'NUEVO rico', 8);


-- 2.-
DELIMITER $$
CREATE OR REPLACE PROCEDURE actualiza_valor_calorico(id_hamburguesa)
BEGIN
    
    DECLARE id_hamburguesa_comprobacion INT(10) default 0;
    DECLARE valor_calorico_teorico double default 0;
    DECLARE valor_calorico_real double default 0;

    SELECT id INTO id_hamburguesa_comprobacion FROM hamburguesa WHERE id=id_hamburguesa;
    select sum(i.valor_calorico) into valor_calorico_teorico from hamburguesa h join hamburguesa_ingredientes hi on h.id = hi.id_hamburguesa 
							                                            join ingrediente i on hi.id_ingrediente = i.id 
                                where h.id = id_hamburguesa;
    select valor_calorico into valor_calorico_real from hamburguesa where id=id_hamburguesa;
    if valor_calorico_teorico!=valor_calorico_real THEN
        UPDATE hamburguesa SET valor_calorico=valor_calorico_teorico WHERE id=id_hamburguesa;
    END IF;
END; 
$$ 
DELIMITER