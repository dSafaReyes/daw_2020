DELIMITER &&
CREATE OR REPLACE FUNCTION vacunar_mascota(
    id_mascota_variable INT(10), id_vacuna_variable INT(10)
) 
RETURNS int(10)
-- Función vacunar mascota. 
-- Devuelve 1 si le corresponde ponerse la vacuna
-- Devuelve 0 si ya superó la cantidad máxima de dosis o si ha habido algún error con los datos
BEGIN
	
    DECLARE id_mascota_real INT(10) DEFAULT 0;
    DECLARE id_vacuna_real INT(10) DEFAULT 0;
    DECLARE id_vacuna_correspondiente INT(10) DEFAULT 0;
    DECLARE cantidad_vacunas INT(10) DEFAULT 0;
    DECLARE cantidad_vacunas_total INT(10) DEFAULT 0;

    -- Comprobar que existe la mascota
    SELECT id INTO id_mascota_real FROM mascota WHERE id=id_mascota_variable;
    -- Comprobar que existe la vacuna
    SELECT id INTO id_vacuna_real FROM vacuna WHERE id=id_vacuna_variable;
    -- Comprobar que la vacuna corresponde a la mascota
    SELECT id_vacuna INTO id_vacuna_correspondiente FROM vacuna_animal WHERE id_vacuna=id_vacuna_variable and id_animal = (select id_animal from mascota where id=id_mascota_variable);
    -- Contar el número de dosis ya puestas
    SELECT COUNT(DISTINCT id) INTO cantidad_vacunas FROM vacunacion_mascota WHERE id_mascota=id_mascota_variable AND id_vacuna=id_vacuna_variable GROUP BY id_mascota;
    -- Comprobar la cantidad máxima de dosis
    SELECT num_dosis INTO cantidad_vacunas_total FROM vacuna WHERE id=id_vacuna_variable;

    IF id_mascota_real=id_mascota_variable AND id_vacuna_real=id_vacuna_variable AND id_vacuna_correspondiente=id_vacuna_variable AND cantidad_vacunas<cantidad_vacunas_total THEN
        INSERT INTO vacunacion_mascota (fecha_vacunacion, id_mascota, id_vacuna) VALUES (CURDATE(), id_mascota_variable, id_vacuna_variable);
        RETURN 1;
    END IF;

    RETURN 0;

END;
&&
DELIMITER
