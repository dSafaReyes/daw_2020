package modelos;

public enum Linea {

    C1, C2, C3, C4, C5, C6 , L1, L2, L3, L4 , L5 ,L6 , A1, A2, A3 , A4, A5, A6;
}
