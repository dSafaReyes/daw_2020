package utilidades;

import modelos.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class UtilidadesConductor {

    public UtilidadesConductor() {
    }


    /**
     * Ejercicio 3A (3 puntos)
     *
     * Dado un conductor y los itinerarios recorridos en un día de trabajo devuelve el resumen de su jornada laboral
     *
     * @param
     * @return
     */
    public static JornadaLaboral terminarJornadaLaboral(Conductor conductor, Map<Autobus,Integer> autobuses_num_itinerarios){
        int num_paradas_totales = autobuses_num_itinerarios.keySet().stream().map(autobus -> autobus.getRecorrido().getParadas()).flatMap(List::stream).toList().size();
        double salario = autobuses_num_itinerarios.entrySet().stream().mapToDouble(e -> e.getKey().getRecorrido().getParadas().stream().mapToDouble(Parada::getBonificacion_parada).sum()*e.getValue()).sum();
        JornadaLaboral jornadaLaboralTerminada = new JornadaLaboral(1, LocalDate.now(), conductor, autobuses_num_itinerarios, num_paradas_totales, salario);
        return  jornadaLaboralTerminada;
    }


    /**
     * Ejercicio 3B (2 puntos)
     *
     * Dado un importe restante de un bono de autobús y una Lista de Autobuses, devuelve la parada en la que quedará sin
     * saldo un viajero de los itinerario de autobuses por orden
     *
     * @param
     * @return
     */
    public static Parada getParadaPosible(Double importe_restante, List<Autobus> autobuses){
        Parada ultimaParada = new Parada();
        for (Autobus autobus:autobuses) {
            List<Parada> paradas = autobus.getRecorrido().getParadas();
            for (Parada parada:paradas) {
                if (importe_restante < parada.getBonificacion_parada()) {
                    System.out.println(paradas.indexOf(parada));
                    ultimaParada = paradas.get(paradas.indexOf(parada));
                    break;
                }
                importe_restante -= parada.getBonificacion_parada();
            }
        }
        return  ultimaParada;
    }







}
