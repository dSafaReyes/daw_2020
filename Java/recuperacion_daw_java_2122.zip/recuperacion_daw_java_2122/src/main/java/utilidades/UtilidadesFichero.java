package utilidades;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import modelos.Autobus;
import modelos.Parada;
import modelos.Recorrido;

import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class UtilidadesFichero {

    public UtilidadesFichero() {
    }

    public static final char SEPARATOR=',';
    public static final char QUOTE='"';
    /**
     *
     * Devuelve la lista de autobuses con sus paradas asignadas leyendo los dos ficheros
     *
     * @return
     */
    public static List<Recorrido> leerRecorridosConParadas() throws IOException {
        List<Recorrido> recorridos = new ArrayList<>();
        CSVReader reader = null;

        try {
            reader = new CSVReader(new FileReader("C:\\Users\\daw20\\Documents\\Java\\recuperacion_daw_java_2122\\src\\main\\java\\archivos\\paradas.csv"),SEPARATOR,QUOTE);
            String[] nextLine= null ;
            int count = 0;
            while ((nextLine = reader.readNext()) != null) {
                if(count > 0) {
                    String[] valores = nextLine;
                    int identi = Integer.parseInt(valores[0]);
                    Parada parada = new Parada();
                    parada.setId(Integer.parseInt(valores[1]));
                    parada.setUbicacion(valores[2]);
                    parada.setNum_parada(Integer.parseInt(valores[3]));
                    parada.setBonificacion_parada(Double.parseDouble(valores[4]));
                    List<Parada> paradas = new ArrayList<>();
                    paradas.add(parada);
                    if (count == 1) {
                        Recorrido recorrido = new Recorrido();
                        recorrido.setId(identi);
                        recorrido.setParadas(paradas);
                        recorridos.add(recorrido);
                        count++;
                        continue;
                    }
                    for (Recorrido recorrido1:recorridos) {
                        if (recorrido1.getId() == identi) {
                            List<Parada> paradas1 = recorrido1.getParadas();
                            paradas1.add(parada);
                            recorrido1.setParadas(paradas1);
                        }
                        else {
                            Recorrido recorrido11 = new Recorrido();
                            recorrido11.setId(identi);
                            recorrido11.setParadas(paradas);
                            recorridos.add(recorrido11);
                        }
                    }
                }
                count++;
            }

        } catch (Exception e) {
            throw e;
        }
        reader.close();
        return recorridos;
    }

}
